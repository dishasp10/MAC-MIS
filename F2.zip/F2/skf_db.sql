/*
Navicat MySQL Data Transfer

Source Server         : school
Source Server Version : 50528
Source Host           : 204.93.216.11:3306
Source Database       : gautam18_skf_final

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2017-04-10 23:47:10
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `activity_master`
-- ----------------------------
DROP TABLE IF EXISTS `activity_master`;
CREATE TABLE `activity_master` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_class_level_id` int(11) DEFAULT NULL,
  `activity_name` varchar(45) DEFAULT NULL,
  `activity_description` varchar(500) DEFAULT NULL,
  `activity_startdate` date DEFAULT NULL,
  `activity_enddate` date DEFAULT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of activity_master
-- ----------------------------
INSERT INTO `activity_master` VALUES ('1', '1', 'Beginner Test Level-1', 'First test of Beginner Level', '2017-04-04', '2017-05-03');
INSERT INTO `activity_master` VALUES ('2', '2', 'Intermediate Level Test-1', 'Intermediate Level first test', '2017-04-06', '2017-05-07');
INSERT INTO `activity_master` VALUES ('3', '1', 'Beginner Test Level-2', 'Second test of Beginner Level', '2017-04-07', '2017-06-03');
INSERT INTO `activity_master` VALUES ('4', '2', 'Intermediate Level Test-2', 'Intermediate Level second test', '2017-04-02', '2017-06-09');

-- ----------------------------
-- Table structure for `address_master`
-- ----------------------------
DROP TABLE IF EXISTS `address_master`;
CREATE TABLE `address_master` (
  `addr_id` int(11) NOT NULL AUTO_INCREMENT,
  `addr_city` varchar(45) DEFAULT NULL,
  `addr_state` varchar(45) DEFAULT NULL,
  `addr_country` varchar(45) DEFAULT NULL,
  `addr_zip` varchar(45) DEFAULT NULL,
  `addr_stu_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`addr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of address_master
-- ----------------------------
INSERT INTO `address_master` VALUES ('1', 'Windsor', 'Ontario', 'Canada', 'N9A-1S5', '1');
INSERT INTO `address_master` VALUES ('2', 'Windsor', 'Ontario', 'Canada', 'N9A-1S5', '2');
INSERT INTO `address_master` VALUES ('3', 'Montreal', 'Quebec', 'Canada', 'K8S-2S6', '3');
INSERT INTO `address_master` VALUES ('4', 'Windsor', 'Ontario', 'Canada', '390018', '4');

-- ----------------------------
-- Table structure for `admin_master`
-- ----------------------------
DROP TABLE IF EXISTS `admin_master`;
CREATE TABLE `admin_master` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(255) DEFAULT NULL,
  `admin_fullname` varchar(255) DEFAULT NULL,
  `admin_email` varchar(255) DEFAULT NULL,
  `admin_phone` varchar(255) DEFAULT NULL,
  `admin_zip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin_master
-- ----------------------------
INSERT INTO `admin_master` VALUES ('1', 'gautam_188@live.com', 'Gautam Sutaria', 'gautam_188@live.com', '9712096161', '390016');
INSERT INTO `admin_master` VALUES ('2', 'rachspatel1989@gmail.com', 'Rachana Patel', 'rachspatel1989@gmail.com', '1234567890', '55882');
INSERT INTO `admin_master` VALUES ('3', 'admin@gmail.com', 'Admin', 'admin@gmail.com', '2134567898', '234567');

-- ----------------------------
-- Table structure for `attendance_master`
-- ----------------------------
DROP TABLE IF EXISTS `attendance_master`;
CREATE TABLE `attendance_master` (
  `attendance_id` int(11) NOT NULL AUTO_INCREMENT,
  `attendance_class_id` int(11) DEFAULT NULL,
  `attendance_stu_id` int(11) DEFAULT NULL,
  `attendance_date` date DEFAULT NULL,
  `attendance_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`attendance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of attendance_master
-- ----------------------------
INSERT INTO `attendance_master` VALUES ('1', '1', '1', '2017-04-10', 'Present');

-- ----------------------------
-- Table structure for `class_level_master`
-- ----------------------------
DROP TABLE IF EXISTS `class_level_master`;
CREATE TABLE `class_level_master` (
  `class_level_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_level` varchar(255) DEFAULT NULL,
  `class_level_desc` varchar(255) DEFAULT NULL,
  `class_start_date` date DEFAULT NULL,
  `class_end_date` date DEFAULT NULL,
  `class_start_time` time DEFAULT NULL,
  `class_end_time` time DEFAULT NULL,
  PRIMARY KEY (`class_level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of class_level_master
-- ----------------------------
INSERT INTO `class_level_master` VALUES ('1', 'Beginner', 'Beginner Desc', '2015-03-18', '2017-04-30', '08:30:00', '11:30:00');
INSERT INTO `class_level_master` VALUES ('2', 'Intermediate', 'Intermediate desc', '2017-03-01', '2017-06-02', '11:30:00', '12:30:00');
INSERT INTO `class_level_master` VALUES ('3', 'Advance', 'Advance Desc', '2017-03-01', '2017-06-02', '08:30:00', '11:20:00');

-- ----------------------------
-- Table structure for `class_master`
-- ----------------------------
DROP TABLE IF EXISTS `class_master`;
CREATE TABLE `class_master` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_level_id` varchar(45) DEFAULT NULL,
  `class_days` varchar(255) DEFAULT NULL,
  `class_level_time` time DEFAULT NULL,
  `class_ins_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of class_master
-- ----------------------------
INSERT INTO `class_master` VALUES ('1', '1', 'Monday', '09:30:00', '1');
INSERT INTO `class_master` VALUES ('2', '1', 'Wednesday', '02:30:00', '1');
INSERT INTO `class_master` VALUES ('3', '2', 'Tuesday', '09:30:00', '1');
INSERT INTO `class_master` VALUES ('4', '2', 'Thursday', '02:30:00', '1');
INSERT INTO `class_master` VALUES ('5', '3', 'Monday', '09:30:00', '1');

-- ----------------------------
-- Table structure for `enroll_master`
-- ----------------------------
DROP TABLE IF EXISTS `enroll_master`;
CREATE TABLE `enroll_master` (
  `enroll_id` int(11) NOT NULL AUTO_INCREMENT,
  `enroll_student_id` int(11) DEFAULT NULL,
  `enroll_class_id` int(11) DEFAULT NULL,
  `enroll_status` varchar(255) DEFAULT NULL,
  `enroll_date` date DEFAULT NULL,
  PRIMARY KEY (`enroll_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of enroll_master
-- ----------------------------
INSERT INTO `enroll_master` VALUES ('1', '1', '1', 'Enrolled', '2017-04-10');
INSERT INTO `enroll_master` VALUES ('2', '2', '3', 'Enrolled', '2017-04-10');
INSERT INTO `enroll_master` VALUES ('3', '3', '2', 'Enrolled', '2017-04-10');
INSERT INTO `enroll_master` VALUES ('4', '2', '5', 'Enrolled', '2017-04-10');

-- ----------------------------
-- Table structure for `fees_history`
-- ----------------------------
DROP TABLE IF EXISTS `fees_history`;
CREATE TABLE `fees_history` (
  `fees_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `fees_stu_id` int(11) DEFAULT NULL,
  `fees_id` int(11) DEFAULT NULL,
  `fees_paid_date` date DEFAULT NULL,
  `fees_paid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fees_history_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fees_history
-- ----------------------------
INSERT INTO `fees_history` VALUES ('1', '1', '1', '2017-04-10', '5000');
INSERT INTO `fees_history` VALUES ('2', '2', '3', '2017-04-18', '7000');

-- ----------------------------
-- Table structure for `fees_master`
-- ----------------------------
DROP TABLE IF EXISTS `fees_master`;
CREATE TABLE `fees_master` (
  `fees_id` int(11) NOT NULL AUTO_INCREMENT,
  `fees_class_level_id` int(11) DEFAULT NULL,
  `fees_type_id` int(11) DEFAULT NULL,
  `fees_amount` float DEFAULT NULL,
  `fees_due_date` date DEFAULT NULL,
  PRIMARY KEY (`fees_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fees_master
-- ----------------------------
INSERT INTO `fees_master` VALUES ('1', '1', '1', '5000', '2017-04-17');
INSERT INTO `fees_master` VALUES ('2', '1', '2', '2000', '2017-04-17');
INSERT INTO `fees_master` VALUES ('3', '2', '1', '7000', '2017-04-17');

-- ----------------------------
-- Table structure for `fees_type_master`
-- ----------------------------
DROP TABLE IF EXISTS `fees_type_master`;
CREATE TABLE `fees_type_master` (
  `fees_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `fees_type_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`fees_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fees_type_master
-- ----------------------------
INSERT INTO `fees_type_master` VALUES ('1', 'Membership');
INSERT INTO `fees_type_master` VALUES ('2', 'Tests');
INSERT INTO `fees_type_master` VALUES ('3', 'Certificates');
INSERT INTO `fees_type_master` VALUES ('4', 'Products');

-- ----------------------------
-- Table structure for `instructor_master`
-- ----------------------------
DROP TABLE IF EXISTS `instructor_master`;
CREATE TABLE `instructor_master` (
  `inst_id` int(11) NOT NULL AUTO_INCREMENT,
  `inst_name` varchar(45) DEFAULT NULL,
  `inst_email` varchar(45) DEFAULT NULL,
  `inst_phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`inst_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of instructor_master
-- ----------------------------
INSERT INTO `instructor_master` VALUES ('1', 'Stephanos', 'sm@gmail.com', '223-435-3546');

-- ----------------------------
-- Table structure for `login_history`
-- ----------------------------
DROP TABLE IF EXISTS `login_history`;
CREATE TABLE `login_history` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_uname` varchar(45) DEFAULT NULL,
  `log_tr_type` varchar(45) DEFAULT NULL,
  `log_datetime` datetime DEFAULT NULL,
  `log_tablename` varchar(45) DEFAULT NULL,
  `log_ip` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of login_history
-- ----------------------------

-- ----------------------------
-- Table structure for `login_master`
-- ----------------------------
DROP TABLE IF EXISTS `login_master`;
CREATE TABLE `login_master` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_uname` varchar(45) DEFAULT NULL,
  `login_password` varchar(45) DEFAULT NULL,
  `login_datetime` datetime DEFAULT NULL,
  `login_usertype` int(45) DEFAULT NULL,
  `login_ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of login_master
-- ----------------------------
INSERT INTO `login_master` VALUES ('1', 'admin@gmail.com', 'admin', '2017-04-10 11:28:02', '1', '::1');
INSERT INTO `login_master` VALUES ('3', 'rachspatel1989@gmail.com', 'student', '2017-04-10 11:33:05', '2', '::1');
INSERT INTO `login_master` VALUES ('4', 'rimsdesai36@gmail.com', 'URcccpkC', '2017-04-10 08:52:34', '2', '::1');
INSERT INTO `login_master` VALUES ('5', 'shahbansu@gmail.com', 'q98xWJdr', '2017-04-10 08:11:06', '2', null);
INSERT INTO `login_master` VALUES ('6', 'charmishah0829@gmail.com', 'aaRZTHOb', '2017-04-10 09:17:11', '2', null);

-- ----------------------------
-- Table structure for `login_type_master`
-- ----------------------------
DROP TABLE IF EXISTS `login_type_master`;
CREATE TABLE `login_type_master` (
  `login_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_type_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`login_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of login_type_master
-- ----------------------------
INSERT INTO `login_type_master` VALUES ('1', 'Master_Admin');
INSERT INTO `login_type_master` VALUES ('2', 'School_Student');

-- ----------------------------
-- Table structure for `parents_master`
-- ----------------------------
DROP TABLE IF EXISTS `parents_master`;
CREATE TABLE `parents_master` (
  `parent_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_stu_id` int(11) DEFAULT NULL,
  `parent_relation_id` int(11) DEFAULT NULL,
  `parent_name` varchar(45) DEFAULT NULL,
  `parent_email` varchar(45) DEFAULT NULL,
  `parent_phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of parents_master
-- ----------------------------
INSERT INTO `parents_master` VALUES ('1', '1', '2', 'Aruna Patel', 'arpatel@gmail.com', '9723873330');
INSERT INTO `parents_master` VALUES ('2', '2', '1', 'Pramod Desai', 'prdesai@gmail.com', '8734688899');
INSERT INTO `parents_master` VALUES ('3', '3', '1', 'Pragnesh Shah', 'psshah@gmail.com', '9788655466');
INSERT INTO `parents_master` VALUES ('4', '4', '1', 'Paresh', 'pshah@gmail.com', '23556677');

-- ----------------------------
-- Table structure for `progress_master`
-- ----------------------------
DROP TABLE IF EXISTS `progress_master`;
CREATE TABLE `progress_master` (
  `progress_id` int(11) NOT NULL AUTO_INCREMENT,
  `progress_stu_id` int(11) DEFAULT NULL,
  `progress_rank_id` int(11) DEFAULT NULL,
  `progress_activity_id` int(11) DEFAULT NULL,
  `progress_date` date DEFAULT NULL,
  `progress_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`progress_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of progress_master
-- ----------------------------
INSERT INTO `progress_master` VALUES ('1', '1', '2', '1', '2017-04-20', 'Clear');
INSERT INTO `progress_master` VALUES ('2', '1', '2', '2', '2017-04-10', 'Clear');
INSERT INTO `progress_master` VALUES ('3', '3', '2', '1', '2017-02-23', 'Clear');

-- ----------------------------
-- Table structure for `rank_history`
-- ----------------------------
DROP TABLE IF EXISTS `rank_history`;
CREATE TABLE `rank_history` (
  `rank_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `rank_type_id` int(11) DEFAULT NULL,
  `rank_stu_id` int(11) DEFAULT NULL,
  `rank_date` date DEFAULT NULL,
  PRIMARY KEY (`rank_history_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of rank_history
-- ----------------------------
INSERT INTO `rank_history` VALUES ('1', '1', '1', '2017-04-10');
INSERT INTO `rank_history` VALUES ('2', '1', '2', '2017-04-10');
INSERT INTO `rank_history` VALUES ('3', '1', '3', '2017-04-10');
INSERT INTO `rank_history` VALUES ('4', '1', '4', '2017-04-10');
INSERT INTO `rank_history` VALUES ('5', '2', '1', '2017-04-10');

-- ----------------------------
-- Table structure for `rank_requirement`
-- ----------------------------
DROP TABLE IF EXISTS `rank_requirement`;
CREATE TABLE `rank_requirement` (
  `rank_requirement_id` int(11) NOT NULL AUTO_INCREMENT,
  `rank_type_id` int(11) DEFAULT NULL,
  `rank_activity_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`rank_requirement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of rank_requirement
-- ----------------------------
INSERT INTO `rank_requirement` VALUES ('1', '2', '1');
INSERT INTO `rank_requirement` VALUES ('2', '2', '2');
INSERT INTO `rank_requirement` VALUES ('3', '3', '3');
INSERT INTO `rank_requirement` VALUES ('4', '3', '4');

-- ----------------------------
-- Table structure for `rank_type_master`
-- ----------------------------
DROP TABLE IF EXISTS `rank_type_master`;
CREATE TABLE `rank_type_master` (
  `rank_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `rank_type_belt` varchar(45) DEFAULT NULL,
  `rank_type_description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`rank_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of rank_type_master
-- ----------------------------
INSERT INTO `rank_type_master` VALUES ('1', 'White', 'Level-1');
INSERT INTO `rank_type_master` VALUES ('2', 'Green', 'Level-2');
INSERT INTO `rank_type_master` VALUES ('3', 'Brown', 'Level-3');
INSERT INTO `rank_type_master` VALUES ('4', 'Black', 'Level-4');

-- ----------------------------
-- Table structure for `relation_trans`
-- ----------------------------
DROP TABLE IF EXISTS `relation_trans`;
CREATE TABLE `relation_trans` (
  `relation_id` int(11) NOT NULL AUTO_INCREMENT,
  `relation_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`relation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of relation_trans
-- ----------------------------
INSERT INTO `relation_trans` VALUES ('1', 'Father');
INSERT INTO `relation_trans` VALUES ('2', 'Mother');

-- ----------------------------
-- Table structure for `student_master`
-- ----------------------------
DROP TABLE IF EXISTS `student_master`;
CREATE TABLE `student_master` (
  `stu_id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_fname` varchar(255) DEFAULT NULL,
  `stu_mname` varchar(255) DEFAULT NULL,
  `stu_lname` varchar(255) DEFAULT NULL,
  `stu_email` varchar(255) DEFAULT NULL,
  `stu_phone` varchar(255) DEFAULT NULL,
  `stu_dob` date DEFAULT NULL,
  `stu_join_date` date DEFAULT NULL,
  `stu_is_active` varchar(255) DEFAULT NULL,
  `stu_available_credit` float DEFAULT NULL,
  PRIMARY KEY (`stu_id`),
  UNIQUE KEY `Unique` (`stu_email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student_master
-- ----------------------------
INSERT INTO `student_master` VALUES ('1', 'Rachana', 'Kamleshbhai', 'Patel', 'rachspatel1989@gmail.com', '226-977-6146', '1989-12-23', '2017-04-05', 'Active', null);
INSERT INTO `student_master` VALUES ('2', 'Reema', 'Pramodbhai', 'Desai', 'rimsdesai36@gmail.com', '613-234-6712', '1991-12-04', '2017-04-06', 'Active', null);
INSERT INTO `student_master` VALUES ('3', 'Bansari', 'Pragneshkumar', 'Shah', 'shahbansu@gmail.com', '225-456-6243', '1994-11-18', '2017-04-07', 'Active', null);
INSERT INTO `student_master` VALUES ('4', 'Charmi', 'Paresh', 'Shah', 'charmishah0829@gmail.com', '224-345-6767', '1994-02-23', '2017-04-13', 'Active', null);
