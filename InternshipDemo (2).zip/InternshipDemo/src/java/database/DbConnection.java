package database;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnection {

    public static Connection getConnect() {
        Connection con = null;
        try
        {
            //Load the Driver according to database
            Class.forName("com.mysql.jdbc.Driver");
            
            // Establish the Connection
            con = DriverManager.getConnection("jdbc:mysql:///internship_db","root", "");
        }
        catch (Exception e)
        {
            System.out.println("Exception in Making Connection" + e);
        }
        return con;
    }
}
