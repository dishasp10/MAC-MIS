/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import database.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Deepak
 */
public class AddStudentDetails1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String student_id1=request.getParameter("student_id1");
        String fname1=request.getParameter("fname1");
        String mname1=request.getParameter("mname1");
        String lname1=request.getParameter("lname1");
        String email1=request.getParameter("email1");
        String password1=request.getParameter("password1");
        String telephone1=request.getParameter("telephone1");
        String gender1=request.getParameter("gender1");
        String country1=request.getParameter("country1");
        String status1=request.getParameter("status1");
        String current_past1=request.getParameter("current_past1");
        String semyear1=request.getParameter("semyear1");
        String gpa1=request.getParameter("gpa1");
        
        try
        {
            Connection con=DbConnection.getConnect();
            PreparedStatement ps=con.prepareStatement("insert into student_details values(?,?,?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, student_id1);
            ps.setString(2, fname1);
            ps.setString(3, mname1);
            ps.setString(4, lname1);
            ps.setString(5, telephone1);
            ps.setString(6, gender1);
            ps.setString(7, country1);
            ps.setString(8, status1);
            ps.setString(9, current_past1);
            ps.setString(10, semyear1);
            ps.setString(11, gpa1);
            ps.setString(12, email1);
            int i1=ps.executeUpdate();
            
            PreparedStatement ps1=con.prepareStatement("insert into register(email, password, role) values(?,?,?)");
            ps1.setString(1, email1);
            ps1.setString(2, password1);
            ps1.setString(3, "3");
            int i2=ps1.executeUpdate();
            
            if(i1>0 && i2>0)
            {
                request.setAttribute("add_stu_msg", "Student Added Successfully");
                RequestDispatcher rd=request.getRequestDispatcher("AddStudent.jsp");  
                rd.forward(request, response);
            }
            else
            {
                response.sendRedirect("ErrorPage.jsp");
            }
        }
        catch(Exception e)
        {
            out.println(e);
        }
        
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
