/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import org.apache.commons.lang.StringUtils;
import database.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Deepak
 */
public class AddJobs extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        
        /*String[] names = request.getParameterValues("checkbox1");
        List list =  Arrays.asList(names);
        out.println(list);*/
        
        String job_group=request.getParameter("job_group");
        String company=request.getParameter("company");
        String internship_type=request.getParameter("internship_type");
        String position=request.getParameter("position");
        String description=request.getParameter("description");
        String responsibilities=request.getParameter("responsibilities");
        String requirements=request.getParameter("requirements");
        String salary=request.getParameter("salary");
        String status=request.getParameter("status");
        String salary_status=request.getParameter("salary_status");
        String[] stu_emails = request.getParameterValues("checkbox1");
        if(stu_emails==null)
        {
            try
            {
                Connection con=DbConnection.getConnect();
                PreparedStatement ps=con.prepareStatement("insert into job_details(job_group, company, internship_type,position,description,responsibilities,requirements,salary,status, salary_status,student_list) values(?,?,?,?,?,?,?,?,?,?,?)");
                ps.setString(1, job_group);
                ps.setString(2, company);
                ps.setString(3, internship_type);
                ps.setString(4, position);
                ps.setString(5, description);
                ps.setString(6, responsibilities);
                ps.setString(7, requirements);
                ps.setString(8, salary);
                ps.setString(9, status);
                ps.setString(10, salary_status);
                ps.setString(11, "Available For All Students");
                int i=ps.executeUpdate();
                if(i>0)
                {
                    request.setAttribute("add_job_msg", "Job Added Successfully");
                    RequestDispatcher rd=request.getRequestDispatcher("AddJobs.jsp");  
                    rd.forward(request, response);
                }
            }
            catch(Exception e)
            {
                out.println(".........."+e);
            }
        }
        else
        {
            List<String> list =  Arrays.asList(stu_emails);
        
            ArrayList<String> listWithQuotes = new ArrayList<String>();
            for(String element : list){
                listWithQuotes.add(element);
            }
            String finalString = StringUtils.join(listWithQuotes.iterator(),",");
            out.println(finalString);
            //out.println(stu_emails);

            try
            {
                Connection con=DbConnection.getConnect();
                PreparedStatement ps=con.prepareStatement("insert into job_details(job_group, company, internship_type,position,description,responsibilities,requirements,salary,status,student_list) values(?,?,?,?,?,?,?,?,?,?)");
                ps.setString(1, job_group);
                ps.setString(2, company);
                ps.setString(3, internship_type);
                ps.setString(4, position);
                ps.setString(5, description);
                ps.setString(6, responsibilities);
                ps.setString(7, requirements);
                ps.setString(8, salary);
                ps.setString(9, status);
                ps.setString(10, finalString);
                int i=ps.executeUpdate();
                if(i>0)
                {
                    request.setAttribute("add_job_msg", "Job Added Successfully");
                    RequestDispatcher rd=request.getRequestDispatcher("AddJobs.jsp");  
                    rd.forward(request, response);
                }
            }
            catch(Exception e)
            {
                out.println("----------"+e);
            }
        }
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
