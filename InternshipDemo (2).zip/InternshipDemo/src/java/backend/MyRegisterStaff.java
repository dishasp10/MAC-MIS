/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend;

import database.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Deepak
 */
public class MyRegisterStaff
{
    public static int registerStaff(String name, String email, String pass, String contact)
    {
        int status = 0, status1=0;
        try
        {
            Connection con=DbConnection.getConnect();
            
            PreparedStatement ps2=con.prepareStatement("insert into register(email, password, role) values(?,?,?)");
            ps2.setString(1, email);
            ps2.setString(2, pass);
            ps2.setString(3, "1");
            status=ps2.executeUpdate();
            
            if(status>0)
            {
                PreparedStatement ps3=con.prepareStatement("insert into staff_details(email, name, contact) values(?,?,?)");
                ps3.setString(1, email);
                ps3.setString(2, name);
                ps3.setString(3, contact);
                status1=ps3.executeUpdate();
            }
            else
            {
                System.out.println("values not inserted into register table");
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return status1;
    }
}
