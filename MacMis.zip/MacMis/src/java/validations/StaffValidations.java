/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author 
 */
public class StaffValidations {

    private Pattern email;
    private Pattern name;
    private Pattern pwd;
    private Pattern contact;
    private Matcher matcher;
    private static final String NAME_PATTERN = "^[A-Za-z ]{3,25}$";
    private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,3})$";
    private static final String PWD_PATTERN = "^[A-Za-z0-9]{5,25}$";
    private static final String CONTACT_PATTERN = "^[0-9]{10}$";

    public StaffValidations() {
        email = Pattern.compile(EMAIL_PATTERN);
        pwd = Pattern.compile(PWD_PATTERN);
        name = Pattern.compile(NAME_PATTERN);
        contact = Pattern.compile(CONTACT_PATTERN);
    }

    /**
     * Validate hex with regular expression
     *
     * @param hex hex for validation
     * @return true valid hex, false invalid hex
     */
    public boolean email_validate(final String hex) {

        matcher = email.matcher(hex);
        return matcher.matches();

    }

    public boolean password_validate(final String hex) {

        matcher = pwd.matcher(hex);
        return matcher.matches();

    }

    public boolean name_validate(final String hex) {

        matcher = name.matcher(hex);
        return matcher.matches();

    }
    
    public boolean contact_validate(final String hex) {

        matcher = contact.matcher(hex);
        return matcher.matches();

    }
}
